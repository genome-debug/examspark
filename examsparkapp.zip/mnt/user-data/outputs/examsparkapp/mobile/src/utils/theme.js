// mobile/src/utils/theme.js

export const Colors = {
  bg: "#0A0A0F",
  surface: "#16161E",
  surfaceHigh: "#1E1E2E",
  border: "#FFFFFF15",
  text: "#F0EDF8",
  textMuted: "#7A6E90",
  textDim: "#4A4460",

  // Exam accent colors
  exams: {
    UPSC: "#FF6B35",
    "JEE Advanced": "#00C9A7",
    NEET: "#FF4D6D",
    CAT: "#845EC2",
    "SSC CGL": "#F9A826",
  },

  distract: "#FF4D6D",
  spark: "#FF6B35",
  success: "#00C9A7",
  warning: "#F9A826",
};

export const Typography = {
  h1: { fontSize: 32, fontWeight: "800", color: Colors.text },
  h2: { fontSize: 24, fontWeight: "700", color: Colors.text },
  h3: { fontSize: 18, fontWeight: "700", color: Colors.text },
  body: { fontSize: 15, fontWeight: "400", color: Colors.text, lineHeight: 22 },
  small: { fontSize: 13, fontWeight: "400", color: Colors.textMuted },
  tiny: { fontSize: 11, fontWeight: "600", color: Colors.textDim, letterSpacing: 0.5 },
  label: { fontSize: 12, fontWeight: "700", letterSpacing: 1, textTransform: "uppercase" },
};

export const Spacing = {
  xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48,
};

export const Radius = {
  sm: 8, md: 12, lg: 16, xl: 20, pill: 50,
};

export const Shadow = {
  sm: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  md: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  glow: (color) => ({
    shadowColor: color,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 16,
    elevation: 10,
  }),
};

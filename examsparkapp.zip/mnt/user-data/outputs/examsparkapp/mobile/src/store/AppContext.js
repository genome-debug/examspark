// mobile/src/store/AppContext.js
// Global state: exam selection, preferences, subscriber ID.

import React, { createContext, useContext, useReducer, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "@examspark:prefs";

const initialState = {
  // Setup
  exam: null,
  subjects: [],
  intervalMinutes: 30,
  distractMode: false,
  subscriberId: null,
  isSetupComplete: false,

  // UI
  notifications: [],   // local history of received sparks
  streakDays: 0,
  totalSparks: 0,
};

function reducer(state, action) {
  switch (action.type) {
    case "SET_EXAM":
      return { ...state, exam: action.payload, subjects: [] };
    case "SET_SUBJECTS":
      return { ...state, subjects: action.payload };
    case "SET_INTERVAL":
      return { ...state, intervalMinutes: action.payload };
    case "SET_DISTRACT_MODE":
      return { ...state, distractMode: action.payload };
    case "SET_SUBSCRIBER_ID":
      return { ...state, subscriberId: action.payload, isSetupComplete: true };
    case "ADD_NOTIFICATION":
      return {
        ...state,
        notifications: [action.payload, ...state.notifications.slice(0, 49)],
        totalSparks: state.totalSparks + 1,
      };
    case "RESTORE":
      return { ...state, ...action.payload };
    case "RESET":
      return initialState;
    default:
      return state;
  }
}

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  // Persist preferences to AsyncStorage on change
  useEffect(() => {
    const toSave = {
      exam: state.exam,
      subjects: state.subjects,
      intervalMinutes: state.intervalMinutes,
      distractMode: state.distractMode,
      subscriberId: state.subscriberId,
      isSetupComplete: state.isSetupComplete,
      streakDays: state.streakDays,
      totalSparks: state.totalSparks,
    };
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
  }, [state.exam, state.subjects, state.intervalMinutes, state.distractMode,
      state.subscriberId, state.isSetupComplete, state.totalSparks]);

  // Restore from storage on mount
  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (raw) {
        try {
          dispatch({ type: "RESTORE", payload: JSON.parse(raw) });
        } catch (_) {}
      }
    });
  }, []);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}

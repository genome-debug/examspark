// mobile/src/services/notifications.js
// Handles device-level push notification setup using @notifee/react-native
// + react-native-push-notification for token retrieval.

import notifee, {
  AndroidImportance,
  AndroidVisibility,
  EventType,
  TriggerType,
} from "@notifee/react-native";
import PushNotification from "react-native-push-notification";
import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { api } from "./api";

const CHANNEL_ID_SPARK = "examspark-spark";
const CHANNEL_ID_DISTRACT = "examspark-distract";
const STORAGE_KEY_SUBSCRIBER_ID = "@examspark:subscriberId";
const STORAGE_KEY_ENDPOINT = "@examspark:endpoint";

/** ── Channels ──────────────────────────────────────────────────────────────── */
export async function createNotificationChannels() {
  // Regular spark channel
  await notifee.createChannel({
    id: CHANNEL_ID_SPARK,
    name: "Study Sparks",
    description: "Motivating facts about your exam syllabus",
    importance: AndroidImportance.HIGH,
    visibility: AndroidVisibility.PUBLIC,
    sound: "default",
    vibration: true,
    vibrationPattern: [100, 50, 100],
  });

  // Distraction mode — maximum urgency
  await notifee.createChannel({
    id: CHANNEL_ID_DISTRACT,
    name: "Focus Mode Alerts",
    description: "Interrupts when you're off-task",
    importance: AndroidImportance.URGENT,
    visibility: AndroidVisibility.PUBLIC,
    sound: "default",
    vibration: true,
    vibrationPattern: [200, 100, 200, 100, 200],
    badge: true,
  });
}

/** ── Permission Request ─────────────────────────────────────────────────────── */
export async function requestPermissions() {
  const settings = await notifee.requestPermission({
    alert: true,
    badge: true,
    sound: true,
    criticalAlert: false,
  });

  return settings.authorizationStatus >= 1; // AUTHORIZED or PROVISIONAL
}

/** ── Token Registration ─────────────────────────────────────────────────────── */
/**
 * Get the device FCM (Android) or APNs (iOS) token,
 * then register with our backend as a push subscriber.
 *
 * Returns the subscriberId from backend.
 */
export async function registerWithBackend({ exam, subjects, intervalMinutes, distractMode }) {
  return new Promise((resolve, reject) => {
    PushNotification.configure({
      // Called when token is generated
      onRegister: async ({ token, os }) => {
        console.log("[Push] Token:", token, "OS:", os);

        try {
          // Wrap raw token in a web-push-compatible subscription shape
          // Backend uses this to identify the device
          const subscription = {
            endpoint: token,
            keys: { platform: os },
          };

          await AsyncStorage.setItem(STORAGE_KEY_ENDPOINT, token);

          const result = await api.subscribe(subscription, {
            exam,
            subjects,
            intervalMinutes,
            distractMode,
          });

          await AsyncStorage.setItem(STORAGE_KEY_SUBSCRIBER_ID, result.subscriberId);
          resolve(result.subscriberId);
        } catch (err) {
          reject(err);
        }
      },

      // Called when a remote notification is received
      onNotification: (notification) => {
        console.log("[Push] Received:", notification);
        notification.finish?.();
      },

      // Called when notification registration fails
      onRegistrationError: reject,

      permissions: { alert: true, badge: true, sound: true },
      popInitialNotification: true,
      requestPermissions: Platform.OS === "ios",

      senderID: "YOUR_FIREBASE_SENDER_ID", // Android: from google-services.json
    });
  });
}

/** ── Show a Local Notification ─────────────────────────────────────────────── */
export async function showLocalNotification({ title, body, forced = false, data = {} }) {
  await notifee.displayNotification({
    title,
    body,
    data,
    android: {
      channelId: forced ? CHANNEL_ID_DISTRACT : CHANNEL_ID_SPARK,
      importance: forced ? AndroidImportance.URGENT : AndroidImportance.HIGH,
      pressAction: { id: "default", launchActivity: "default" },
      actions: [
        {
          title: "🔥 Study Now",
          pressAction: { id: "study" },
        },
        {
          title: "Later",
          pressAction: { id: "dismiss" },
        },
      ],
      largeIcon: "ic_launcher",
      smallIcon: "ic_notification",
      color: forced ? "#FF4D6D" : "#FF6B35",
      vibrationPattern: forced ? [200, 100, 200, 100, 200] : [100, 50, 100],
    },
    ios: {
      sound: "default",
      interruptionLevel: forced ? "critical" : "active",
      categoryId: "SPARK",
    },
  });
}

/** ── Notification Event Handlers ─────────────────────────────────────────────── */
export function registerNotificationHandlers(navigationRef) {
  return notifee.onForegroundEvent(({ type, detail }) => {
    if (type === EventType.PRESS) {
      const { topic, chapter, unit } = detail.notification?.data || {};
      console.log(`[Notif] Tapped → ${topic} (${chapter})`);
      // Navigate to topic detail screen
      navigationRef?.current?.navigate("TopicDetail", { topic, chapter, unit });
    }

    if (type === EventType.ACTION_PRESS) {
      if (detail.pressAction.id === "study") {
        navigationRef?.current?.navigate("Dashboard");
      }
    }
  });
}

/** ── Persist & Retrieve Subscriber Info ─────────────────────────────────────── */
export async function getStoredSubscriberId() {
  return AsyncStorage.getItem(STORAGE_KEY_SUBSCRIBER_ID);
}

export async function getStoredEndpoint() {
  return AsyncStorage.getItem(STORAGE_KEY_ENDPOINT);
}

export async function clearStoredSubscription() {
  await AsyncStorage.multiRemove([STORAGE_KEY_SUBSCRIBER_ID, STORAGE_KEY_ENDPOINT]);
}

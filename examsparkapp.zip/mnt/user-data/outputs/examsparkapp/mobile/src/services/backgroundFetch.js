// mobile/src/services/backgroundFetch.js
// Uses react-native-background-fetch to periodically ping the backend
// and trigger distract-mode notifications when the app is in background.
//
// Android: Works via JobScheduler / AlarmManager
// iOS:     Works via BGAppRefreshTask (limited by OS to ~15 min intervals)

import BackgroundFetch from "react-native-background-fetch";
import { api } from "./api";
import { getStoredSubscriberId, showLocalNotification } from "./notifications";

const DISTRACT_FACTS = [
  { title: "🚨 Hey! Stop Scrolling — Study Time!", body: "Every minute on social media is a minute away from your goal. Lock in! 💪" },
  { title: "📵 Focus Alert!", body: "Your exam date is getting closer. Close the apps and open your books! 📚" },
  { title: "⚡ ExamSpark Interrupting!", body: "Top rankers study while others scroll. Which one are you? 🏆" },
  { title: "🔥 Distraction Detected!", body: "Your future self is watching you right now. Don't disappoint them. 🎯" },
];

export async function configureBackgroundFetch(distractMode) {
  const status = await BackgroundFetch.configure(
    {
      minimumFetchInterval: 1,          // minutes (iOS honours minimum ~15m)
      stopOnTerminate: false,
      startOnBoot: true,
      enableHeadless: true,             // Android headless task
      requiredNetworkType: BackgroundFetch.NETWORK_TYPE_ANY,
    },
    async (taskId) => {
      console.log("[BackgroundFetch] Task:", taskId);

      if (distractMode) {
        const fact = DISTRACT_FACTS[Math.floor(Math.random() * DISTRACT_FACTS.length)];
        await showLocalNotification({
          title: fact.title,
          body: fact.body,
          forced: true,
        });
      }

      // Also tell the backend we're alive (backend sends push too)
      try {
        const subscriberId = await getStoredSubscriberId();
        if (subscriberId) await api.sparkNow(subscriberId);
      } catch (_) {}

      BackgroundFetch.finish(taskId);
    },
    (taskId) => {
      // Task timeout — must call finish
      console.warn("[BackgroundFetch] Timeout:", taskId);
      BackgroundFetch.finish(taskId);
    }
  );

  console.log("[BackgroundFetch] Status:", status);
  return status;
}

// Android Headless Task — runs when app is terminated
export const headlessTask = async (event) => {
  const taskId = event.taskId;
  console.log("[BackgroundFetch Headless] Task:", taskId);
  // Fire a notification even when app is completely closed
  await showLocalNotification({
    title: "⚡ ExamSpark",
    body: "Time for a quick study spark! Tap to get today's best fact 🚀",
    forced: false,
  });
  BackgroundFetch.finish(taskId);
};

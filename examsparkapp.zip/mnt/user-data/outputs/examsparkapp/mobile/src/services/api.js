// mobile/src/services/api.js
// All calls to the ExamSpark backend

const BASE_URL = __DEV__
  ? "http://10.0.2.2:4000/api"   // Android emulator → localhost
  : "https://api.examspark.app/api"; // Production

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

export const api = {
  /** Get available exams and their subjects */
  getExams: () => request("/exams"),

  /** Get VAPID public key for push subscription */
  getVapidKey: () => request("/vapid-public-key"),

  /**
   * Register/update push subscription
   * @param {object} subscription - FCM/APNs token wrapped as push subscription
   * @param {object} prefs - { exam, subjects, intervalMinutes, distractMode }
   */
  subscribe: (subscription, prefs) =>
    request("/subscribe", {
      method: "POST",
      body: { subscription, ...prefs },
    }),

  /** Update notification preferences without re-subscribing */
  updatePrefs: (endpoint, prefs) =>
    request("/subscribe", {
      method: "PATCH",
      body: { endpoint, ...prefs },
    }),

  /** Remove subscription */
  unsubscribe: (endpoint) =>
    request("/subscribe", {
      method: "DELETE",
      body: { endpoint },
    }),

  /** Trigger an immediate spark notification */
  sparkNow: (subscriberId) =>
    request("/spark", {
      method: "POST",
      body: { subscriberId },
    }),

  /** Health check */
  health: () => request("/health"),
};

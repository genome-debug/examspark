// mobile/src/screens/ExamSelectScreen.js
import React, { useState, useEffect } from "react";
import {
  View, Text, TouchableOpacity, FlatList,
  StyleSheet, SafeAreaView, ActivityIndicator,
} from "react-native";
import { api } from "../services/api";
import { useApp } from "../store/AppContext";
import { Colors, Typography, Spacing, Radius } from "../utils/theme";

export default function ExamSelectScreen({ navigation }) {
  const { dispatch } = useApp();
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getExams()
      .then((d) => setExams(d.exams))
      .catch(() => {
        // Fallback offline data
        setExams([
          { name: "UPSC", emoji: "🏛️", subjects: [] },
          { name: "JEE Advanced", emoji: "⚡", subjects: [] },
          { name: "NEET", emoji: "🩺", subjects: [] },
          { name: "CAT", emoji: "📊", subjects: [] },
          { name: "SSC CGL", emoji: "🎯", subjects: [] },
        ]);
      })
      .finally(() => setLoading(false));
  }, []);

  const handleSelect = (exam) => {
    dispatch({ type: "SET_EXAM", payload: exam.name });
    navigation.navigate("SubjectSelect", { exam });
  };

  const accentColor = (name) => Colors.exams[name] || Colors.spark;

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safe}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.back}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>

        <Text style={styles.title}>Pick Your Battle</Text>
        <Text style={styles.subtitle}>Which exam are you preparing for?</Text>

        {loading ? (
          <ActivityIndicator color={Colors.spark} size="large" style={{ marginTop: 60 }} />
        ) : (
          <FlatList
            data={exams}
            keyExtractor={(item) => item.name}
            contentContainerStyle={styles.list}
            renderItem={({ item }) => {
              const color = accentColor(item.name);
              return (
                <TouchableOpacity
                  style={[styles.card, { borderColor: `${color}40` }]}
                  onPress={() => handleSelect(item)}
                  activeOpacity={0.8}
                >
                  <Text style={styles.cardEmoji}>{item.emoji}</Text>
                  <View style={styles.cardInfo}>
                    <Text style={styles.cardName}>{item.name}</Text>
                    <Text style={[styles.cardMeta, { color }]}>
                      {item.subjects.length} subjects
                      {item.subjects.length > 0
                        ? ` · ${item.subjects.reduce((a, s) => a + (s.topics?.length || 0), 0)} topics`
                        : ""}
                    </Text>
                  </View>
                  <View style={[styles.arrow, { backgroundColor: `${color}20`, borderColor: `${color}40` }]}>
                    <Text style={{ color }}>→</Text>
                  </View>
                </TouchableOpacity>
              );
            }}
          />
        )}
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  safe: { flex: 1, paddingHorizontal: Spacing.md },
  back: { paddingVertical: Spacing.md },
  backText: { ...Typography.body, color: Colors.textMuted },
  title: { ...Typography.h2, marginBottom: 6 },
  subtitle: { ...Typography.small, marginBottom: Spacing.lg },
  list: { paddingBottom: Spacing.xl },
  card: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderRadius: Radius.xl,
    padding: Spacing.md,
    marginBottom: 12,
    borderWidth: 1,
    gap: Spacing.md,
  },
  cardEmoji: { fontSize: 36 },
  cardInfo: { flex: 1 },
  cardName: { ...Typography.h3, fontSize: 17 },
  cardMeta: { ...Typography.small, marginTop: 2 },
  arrow: {
    width: 36, height: 36, borderRadius: 18,
    alignItems: "center", justifyContent: "center",
    borderWidth: 1,
  },
});

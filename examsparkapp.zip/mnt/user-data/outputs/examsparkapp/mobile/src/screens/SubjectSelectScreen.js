// mobile/src/screens/SubjectSelectScreen.js
import React, { useState } from "react";
import {
  View, Text, TouchableOpacity, FlatList, StyleSheet,
  SafeAreaView,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useApp } from "../store/AppContext";
import { Colors, Typography, Spacing, Radius } from "../utils/theme";

export default function SubjectSelectScreen({ route, navigation }) {
  const { exam } = route.params;
  const { state, dispatch } = useApp();
  const [selected, setSelected] = useState(
    state.subjects.length > 0 ? state.subjects : exam.subjects.map((s) => s.name)
  );

  const accentColor = Colors.exams[exam.name] || Colors.spark;

  const toggle = (name) => {
    setSelected((prev) =>
      prev.includes(name) ? prev.filter((s) => s !== name) : [...prev, name]
    );
  };

  const handleNext = () => {
    dispatch({ type: "SET_SUBJECTS", payload: selected });
    navigation.navigate("NotificationSettings");
  };

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safe}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.back}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>

        <View style={styles.titleRow}>
          <Text style={styles.emoji}>{exam.emoji}</Text>
          <Text style={styles.title}>{exam.name}</Text>
        </View>
        <Text style={styles.subtitle}>Select subjects to receive fact sparks from</Text>

        <FlatList
          data={exam.subjects}
          keyExtractor={(item) => item.name}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => {
            const isSelected = selected.includes(item.name);
            return (
              <TouchableOpacity
                onPress={() => toggle(item.name)}
                activeOpacity={0.8}
                style={[styles.card, {
                  borderColor: isSelected ? accentColor : Colors.border,
                  backgroundColor: isSelected ? `${accentColor}12` : Colors.surface,
                }]}
              >
                <Text style={styles.subjectIcon}>{item.icon}</Text>
                <View style={styles.subjectInfo}>
                  <Text style={styles.subjectName}>{item.name}</Text>
                  {item.topics?.length > 0 && (
                    <Text style={styles.subjectTopics} numberOfLines={1}>
                      {item.topics.slice(0, 3).join(", ")}...
                    </Text>
                  )}
                </View>
                <View style={[styles.checkbox, {
                  backgroundColor: isSelected ? accentColor : "transparent",
                  borderColor: isSelected ? accentColor : Colors.textDim,
                }]}>
                  {isSelected && <Text style={styles.checkmark}>✓</Text>}
                </View>
              </TouchableOpacity>
            );
          }}
        />

        <View style={styles.footer}>
          <TouchableOpacity
            onPress={handleNext}
            disabled={selected.length === 0}
            activeOpacity={0.85}
            style={{ borderRadius: Radius.lg, overflow: "hidden" }}
          >
            <LinearGradient
              colors={selected.length > 0 ? [accentColor, `${accentColor}88`] : [Colors.surfaceHigh, Colors.surfaceHigh]}
              style={styles.nextBtn}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            >
              <Text style={styles.nextBtnText}>
                {selected.length > 0
                  ? `Set Notifications for ${selected.length} Subject${selected.length > 1 ? "s" : ""} →`
                  : "Select at least 1 subject"}
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  safe: { flex: 1, paddingHorizontal: Spacing.md },
  back: { paddingVertical: Spacing.md },
  backText: { color: Colors.textMuted },
  titleRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 6 },
  emoji: { fontSize: 28 },
  title: { ...Typography.h2 },
  subtitle: { ...Typography.small, marginBottom: Spacing.lg },
  list: { paddingBottom: 100 },
  card: {
    flexDirection: "row", alignItems: "center", gap: 14,
    borderRadius: Radius.xl, padding: Spacing.md, marginBottom: 10, borderWidth: 1.5,
  },
  subjectIcon: { fontSize: 26 },
  subjectInfo: { flex: 1 },
  subjectName: { ...Typography.body, fontWeight: "700" },
  subjectTopics: { ...Typography.small, marginTop: 2, color: Colors.textDim },
  checkbox: {
    width: 24, height: 24, borderRadius: 12, borderWidth: 2,
    alignItems: "center", justifyContent: "center",
  },
  checkmark: { color: "#fff", fontSize: 13, fontWeight: "700" },
  footer: { position: "absolute", bottom: 0, left: 0, right: 0, padding: Spacing.md, paddingBottom: Spacing.lg, backgroundColor: Colors.bg },
  nextBtn: { paddingVertical: 16, alignItems: "center", borderRadius: Radius.lg },
  nextBtnText: { color: "#fff", fontWeight: "700", fontSize: 15 },
});

// mobile/src/screens/NotificationSettingsScreen.js
import React, { useState } from "react";
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  ScrollView, Switch, Alert, ActivityIndicator,
} from "react-native";
import Slider from "@react-native-community/slider";
import LinearGradient from "react-native-linear-gradient";
import { useApp } from "../store/AppContext";
import { Colors, Typography, Spacing, Radius } from "../utils/theme";
import {
  requestPermissions,
  createNotificationChannels,
  registerWithBackend,
  configureBackgroundFetch,
} from "../services/notifications";
import { api } from "../services/api";

export default function NotificationSettingsScreen({ navigation }) {
  const { state, dispatch } = useApp();
  const [intervalMinutes, setIntervalMinutes] = useState(state.intervalMinutes || 30);
  const [distractMode, setDistractMode] = useState(state.distractMode);
  const [loading, setLoading] = useState(false);

  const accentColor = Colors.exams[state.exam] || Colors.spark;

  const freqLabel = (m) => {
    if (m <= 5) return "🔥 Power mode — intense sprint sessions";
    if (m <= 15) return "⚡ Great rhythm — one fact per topic";
    if (m <= 30) return "📚 Calm & steady — deep reading mode";
    return "🌙 Gentle — perfect for night sessions";
  };

  const handleStart = async () => {
    setLoading(true);
    try {
      // 1. Request OS permission
      const granted = await requestPermissions();
      if (!granted) {
        Alert.alert(
          "Notifications Blocked",
          "Please enable notifications for ExamSpark in your device Settings to receive study sparks.",
          [{ text: "OK" }]
        );
        setLoading(false);
        return;
      }

      // 2. Create notification channels (Android)
      await createNotificationChannels();

      // 3. Register device with backend + get subscriberId
      const subscriberId = await registerWithBackend({
        exam: state.exam,
        subjects: state.subjects,
        intervalMinutes,
        distractMode,
      });

      // 4. Save prefs to global state
      dispatch({ type: "SET_INTERVAL", payload: intervalMinutes });
      dispatch({ type: "SET_DISTRACT_MODE", payload: distractMode });
      dispatch({ type: "SET_SUBSCRIBER_ID", payload: subscriberId });

      // 5. Configure background fetch for distract mode
      await configureBackgroundFetch(distractMode);

      navigation.reset({ index: 0, routes: [{ name: "Dashboard" }] });
    } catch (err) {
      console.error("[Setup] Error:", err);
      Alert.alert("Setup Failed", err.message || "Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateExisting = async () => {
    setLoading(true);
    try {
      const { getStoredEndpoint } = require("../services/notifications");
      const endpoint = await getStoredEndpoint();
      if (endpoint) {
        await api.updatePrefs(endpoint, { intervalMinutes, distractMode, subjects: state.subjects });
      }
      dispatch({ type: "SET_INTERVAL", payload: intervalMinutes });
      dispatch({ type: "SET_DISTRACT_MODE", payload: distractMode });
      navigation.goBack();
    } catch (err) {
      Alert.alert("Update Failed", err.message);
    } finally {
      setLoading(false);
    }
  };

  const isUpdate = !!state.subscriberId;

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safe}>
        <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.back}>
            <Text style={styles.backText}>← Back</Text>
          </TouchableOpacity>

          <Text style={styles.title}>Set Your Spark Frequency</Text>
          <Text style={styles.subtitle}>How often do you want to be ignited?</Text>

          {/* Frequency Card */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <View>
                <Text style={styles.cardTitle}>📲 Notification Frequency</Text>
                <Text style={styles.cardDesc}>During study sessions</Text>
              </View>
              <View style={[styles.badge, { backgroundColor: `${accentColor}20` }]}>
                <Text style={[styles.badgeNum, { color: accentColor }]}>{intervalMinutes}</Text>
                <Text style={styles.badgeUnit}>min</Text>
              </View>
            </View>

            <Slider
              style={styles.slider}
              minimumValue={2}
              maximumValue={60}
              step={1}
              value={intervalMinutes}
              onValueChange={setIntervalMinutes}
              minimumTrackTintColor={accentColor}
              maximumTrackTintColor={Colors.border}
              thumbTintColor={accentColor}
            />

            <View style={styles.sliderLabels}>
              {["2m\nIntense", "30m\nBalanced", "60m\nGentle"].map((l) => (
                <Text key={l} style={styles.sliderLabel}>{l}</Text>
              ))}
            </View>

            <View style={[styles.hint, { backgroundColor: `${accentColor}15`, borderColor: `${accentColor}25` }]}>
              <Text style={[styles.hintText, { color: Colors.textMuted }]}>
                {freqLabel(intervalMinutes)}
              </Text>
            </View>
          </View>

          {/* Distraction Radar Card */}
          <View style={styles.card}>
            <View style={styles.distractRow}>
              <View style={{ flex: 1, marginRight: Spacing.md }}>
                <Text style={styles.cardTitle}>📵 Distraction Radar</Text>
                <Text style={[styles.cardDesc, { marginTop: 4, lineHeight: 20 }]}>
                  If you're mindlessly scrolling, ExamSpark fires a rapid-burst alert every 30 seconds to pull you back!
                </Text>
              </View>
              <Switch
                value={distractMode}
                onValueChange={setDistractMode}
                trackColor={{ false: "#2A2A3A", true: Colors.distract }}
                thumbColor="#fff"
              />
            </View>
            {distractMode && (
              <View style={styles.distractAlert}>
                <Text style={styles.distractAlertText}>
                  🚨 Active — interrupts every 30 seconds when you're off-track
                </Text>
              </View>
            )}
          </View>

          {/* CTA */}
          <TouchableOpacity
            onPress={isUpdate ? handleUpdateExisting : handleStart}
            disabled={loading}
            activeOpacity={0.85}
            style={styles.ctaWrapper}
          >
            <LinearGradient
              colors={[accentColor, `${accentColor}88`]}
              style={styles.cta}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
            >
              {loading
                ? <ActivityIndicator color="#fff" />
                : <Text style={styles.ctaText}>{isUpdate ? "💾 Save Changes" : "🚀 Start Sparking!"}</Text>
              }
            </LinearGradient>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  safe: { flex: 1 },
  scroll: { padding: Spacing.md, paddingBottom: Spacing.xxl },
  back: { paddingVertical: Spacing.md },
  backText: { color: Colors.textMuted },
  title: { ...Typography.h2, marginBottom: 6 },
  subtitle: { ...Typography.small, marginBottom: Spacing.lg },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.xl,
    padding: Spacing.md,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  cardHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: Spacing.md },
  cardTitle: { ...Typography.body, fontWeight: "700" },
  cardDesc: { ...Typography.small, marginTop: 2 },
  badge: { borderRadius: Radius.md, padding: Spacing.sm, alignItems: "center", minWidth: 64 },
  badgeNum: { fontSize: 28, fontWeight: "800" },
  badgeUnit: { ...Typography.tiny, color: Colors.textMuted },
  slider: { width: "100%", height: 40 },
  sliderLabels: { flexDirection: "row", justifyContent: "space-between" },
  sliderLabel: { ...Typography.tiny, textAlign: "center", color: Colors.textDim },
  hint: { marginTop: Spacing.sm, borderRadius: Radius.md, padding: 12, borderWidth: 1 },
  hintText: { ...Typography.small },
  distractRow: { flexDirection: "row", alignItems: "center" },
  distractAlert: {
    marginTop: Spacing.sm,
    backgroundColor: "#FF4D6D18",
    borderRadius: Radius.md,
    padding: 10,
    borderWidth: 1,
    borderColor: "#FF4D6D30",
  },
  distractAlertText: { ...Typography.small, color: "#FF8FA0" },
  ctaWrapper: { borderRadius: Radius.lg, overflow: "hidden", marginTop: Spacing.sm },
  cta: { paddingVertical: 18, alignItems: "center" },
  ctaText: { color: "#fff", fontWeight: "800", fontSize: 17 },
});

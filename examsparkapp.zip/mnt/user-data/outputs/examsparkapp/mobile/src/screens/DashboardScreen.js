// mobile/src/screens/DashboardScreen.js
import React, { useEffect, useRef, useState } from "react";
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  ScrollView, Animated, Alert, RefreshControl,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useApp } from "../store/AppContext";
import { Colors, Typography, Spacing, Radius, Shadow } from "../utils/theme";
import { api } from "../services/api";

export default function DashboardScreen({ navigation }) {
  const { state, dispatch } = useApp();
  const [loading, setLoading] = useState(false);
  const pulseAnim = useRef(new Animated.Value(1)).current;

  const accentColor = Colors.exams[state.exam] || Colors.spark;

  // Pulse animation for live indicator
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.4, duration: 900, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 900, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  const handleSparkNow = async () => {
    if (!state.subscriberId) return;
    setLoading(true);
    try {
      await api.sparkNow(state.subscriberId);
      Alert.alert("⚡ Spark Sent!", "Check your notification shade in a moment 🚀");
    } catch (err) {
      Alert.alert("Oops", "Couldn't send spark right now. Try again!");
    } finally {
      setLoading(false);
    }
  };

  const toggleDistractMode = async () => {
    const newMode = !state.distractMode;
    dispatch({ type: "SET_DISTRACT_MODE", payload: newMode });
    try {
      const { getStoredEndpoint } = require("../services/notifications");
      const endpoint = await getStoredEndpoint();
      if (endpoint) await api.updatePrefs(endpoint, { distractMode: newMode });
    } catch (_) {}
  };

  const stats = [
    { label: "Today", value: state.notifications.filter(n => {
        const d = new Date(n.receivedAt);
        return d.toDateString() === new Date().toDateString();
      }).length, icon: "⚡", color: accentColor },
    { label: "Streak", value: `${state.streakDays}d`, icon: "🔥", color: "#FF9A3C" },
    { label: "Total", value: state.totalSparks, icon: "✨", color: "#845EC2" },
  ];

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safe}>
        <ScrollView
          contentContainerStyle={styles.scroll}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={loading} onRefresh={handleSparkNow} tintColor={accentColor} />}
        >
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.headerLeft}>
              <Text style={styles.headerEmoji}>
                {state.exam === "UPSC" ? "🏛️" :
                 state.exam === "JEE Advanced" ? "⚡" :
                 state.exam === "NEET" ? "🩺" :
                 state.exam === "CAT" ? "📊" : "🎯"}
              </Text>
              <View>
                <Text style={styles.headerTitle}>{state.exam}</Text>
                <Text style={styles.headerSub}>{state.subjects.length} subjects active</Text>
              </View>
            </View>
            <View style={styles.liveBadge}>
              <Animated.View style={[styles.liveDot, { backgroundColor: accentColor, transform: [{ scale: pulseAnim }], opacity: 0.4, position: "absolute" }]} />
              <View style={[styles.liveDot, { backgroundColor: accentColor }]} />
              <Text style={[styles.liveText, { color: accentColor }]}>LIVE</Text>
            </View>
          </View>

          {/* Stats */}
          <View style={styles.stats}>
            {stats.map((s) => (
              <View key={s.label} style={[styles.statCard, { borderColor: `${s.color}20` }]}>
                <Text style={styles.statIcon}>{s.icon}</Text>
                <Text style={[styles.statValue, { color: s.color }]}>{s.value}</Text>
                <Text style={styles.statLabel}>{s.label}</Text>
              </View>
            ))}
          </View>

          {/* Controls */}
          <View style={styles.controls}>
            <Text style={styles.sectionTitle}>QUICK CONTROLS</Text>
            <View style={styles.btnRow}>
              {/* Spark Now */}
              <TouchableOpacity
                style={styles.btnHalf}
                onPress={handleSparkNow}
                disabled={loading}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[accentColor, `${accentColor}99`]}
                  style={styles.btnGradient}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                >
                  <Text style={styles.btnText}>⚡ Spark Me Now!</Text>
                </LinearGradient>
              </TouchableOpacity>

              {/* Distract Toggle */}
              <TouchableOpacity
                style={styles.btnHalf}
                onPress={toggleDistractMode}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={state.distractMode
                    ? ["#FF4D6D", "#FF9A3C"]
                    : [Colors.surfaceHigh, Colors.surfaceHigh]}
                  style={[styles.btnGradient, state.distractMode && Shadow.glow(Colors.distract)]}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                >
                  <Text style={styles.btnText}>
                    {state.distractMode ? "🚨 Focus ON" : "📵 Focus OFF"}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>

            {/* Interval Info */}
            <View style={styles.intervalRow}>
              <Text style={styles.intervalText}>
                Next spark in: <Text style={{ color: accentColor, fontWeight: "700" }}>{state.intervalMinutes} min intervals</Text>
              </Text>
              <TouchableOpacity onPress={() => navigation.navigate("NotificationSettings")}>
                <Text style={[styles.changeBtn, { color: accentColor }]}>Change</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Active Subjects */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>ACTIVE SUBJECTS</Text>
            <View style={styles.subjectChips}>
              {state.subjects.map((s) => (
                <View key={s} style={[styles.chip, { backgroundColor: `${accentColor}15`, borderColor: `${accentColor}30` }]}>
                  <Text style={[styles.chipText, { color: accentColor }]}>{s}</Text>
                </View>
              ))}
            </View>
          </View>

          {/* Recent Sparks */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>RECENT SPARKS</Text>
            {state.notifications.length === 0 ? (
              <View style={styles.emptyCard}>
                <Text style={styles.emptyEmoji}>⚡</Text>
                <Text style={styles.emptyTitle}>Your first spark is loading...</Text>
                <Text style={styles.emptyDesc}>Hit "Spark Me Now!" to get your first fact instantly!</Text>
              </View>
            ) : (
              state.notifications.slice(0, 5).map((n, i) => (
                <View key={n.id} style={[styles.notifCard, { opacity: Math.max(0.4, 1 - i * 0.15), borderColor: n.forced ? "#FF4D6D20" : `${accentColor}15` }]}>
                  <View style={styles.notifHeader}>
                    <Text style={styles.notifIcon}>{n.icon || "📚"}</Text>
                    <Text style={styles.notifTopic}>{n.topic}</Text>
                    {n.forced && (
                      <View style={styles.focusBadge}>
                        <Text style={styles.focusBadgeText}>FOCUS</Text>
                      </View>
                    )}
                  </View>
                  <Text style={styles.notifBody} numberOfLines={2}>{n.body}</Text>
                </View>
              ))
            )}
          </View>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  safe: { flex: 1 },
  scroll: { padding: Spacing.md, paddingBottom: 100 },

  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: Spacing.lg },
  headerLeft: { flexDirection: "row", alignItems: "center", gap: 10 },
  headerEmoji: { fontSize: 28 },
  headerTitle: { ...Typography.h3 },
  headerSub: { ...Typography.tiny, color: Colors.textMuted },
  liveBadge: { flexDirection: "row", alignItems: "center", gap: 6 },
  liveDot: { width: 10, height: 10, borderRadius: 5 },
  liveText: { ...Typography.label, fontSize: 11 },

  stats: { flexDirection: "row", gap: 10, marginBottom: Spacing.md },
  statCard: {
    flex: 1, backgroundColor: Colors.surface,
    borderRadius: Radius.lg, padding: 14, alignItems: "center",
    borderWidth: 1,
  },
  statIcon: { fontSize: 18, marginBottom: 4 },
  statValue: { fontSize: 22, fontWeight: "800" },
  statLabel: { ...Typography.tiny, marginTop: 2 },

  controls: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.md, marginBottom: Spacing.md },
  sectionTitle: { ...Typography.label, color: Colors.textMuted, fontSize: 11, marginBottom: 12 },
  btnRow: { flexDirection: "row", gap: 10, marginBottom: 12 },
  btnHalf: { flex: 1, borderRadius: Radius.md, overflow: "hidden" },
  btnGradient: { paddingVertical: 13, alignItems: "center", borderRadius: Radius.md },
  btnText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  intervalRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  intervalText: { ...Typography.small },
  changeBtn: { ...Typography.small, fontWeight: "700" },

  section: { marginBottom: Spacing.md },
  subjectChips: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.pill, borderWidth: 1 },
  chipText: { ...Typography.small, fontWeight: "600" },

  emptyCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    padding: Spacing.xl, alignItems: "center",
    borderWidth: 1, borderColor: Colors.border, borderStyle: "dashed",
  },
  emptyEmoji: { fontSize: 36, marginBottom: 10 },
  emptyTitle: { ...Typography.body, fontWeight: "700", marginBottom: 4 },
  emptyDesc: { ...Typography.small, textAlign: "center" },

  notifCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.lg,
    padding: 14, marginBottom: 10, borderWidth: 1,
  },
  notifHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 6 },
  notifIcon: { fontSize: 18 },
  notifTopic: { ...Typography.body, fontWeight: "700", flex: 1 },
  focusBadge: { backgroundColor: "#FF4D6D20", borderRadius: Radius.pill, paddingHorizontal: 8, paddingVertical: 2 },
  focusBadgeText: { fontSize: 10, color: "#FF4D6D", fontWeight: "700" },
  notifBody: { ...Typography.small, lineHeight: 19 },
});

// mobile/src/screens/WelcomeScreen.js
import React, { useEffect, useRef } from "react";
import {
  View, Text, TouchableOpacity, StyleSheet,
  Animated, StatusBar, SafeAreaView,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Colors, Typography, Spacing, Radius } from "../utils/theme";

export default function WelcomeScreen({ navigation }) {
  const floatAnim = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Float animation for rocket emoji
    Animated.loop(
      Animated.sequence([
        Animated.timing(floatAnim, { toValue: -12, duration: 1500, useNativeDriver: true }),
        Animated.timing(floatAnim, { toValue: 0, duration: 1500, useNativeDriver: true }),
      ])
    ).start();

    // Fade in content
    Animated.timing(fadeAnim, { toValue: 1, duration: 800, delay: 200, useNativeDriver: true }).start();
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bg} />
      <LinearGradient
        colors={["#FF6B3510", "#0A0A0F", "#845EC210"]}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      />

      <SafeAreaView style={styles.safe}>
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          {/* Rocket */}
          <Animated.Text style={[styles.emoji, { transform: [{ translateY: floatAnim }] }]}>
            🚀
          </Animated.Text>

          {/* Badge */}
          <View style={styles.badge}>
            <Text style={styles.badgeText}>INTRODUCING</Text>
          </View>

          {/* Title */}
          <Text style={styles.title}>ExamSpark</Text>
          <Text style={styles.subtitle}>
            AI-powered study nudges that make you{" "}
            <Text style={{ color: Colors.spark, fontStyle: "italic" }}>curious</Text>
            {" "}about your syllabus — not dreaded of it.
          </Text>

          {/* Feature Pills */}
          <View style={styles.pills}>
            {["🧠 Smart Facts", "🔥 Topic Hooks", "📵 Focus Mode"].map((f) => (
              <View key={f} style={styles.pill}>
                <Text style={styles.pillText}>{f}</Text>
              </View>
            ))}
          </View>

          {/* CTA */}
          <TouchableOpacity
            style={styles.ctaWrapper}
            onPress={() => navigation.navigate("ExamSelect")}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={["#FF6B35", "#FF9A3C"]}
              style={styles.cta}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
            >
              <Text style={styles.ctaText}>Choose My Exam →</Text>
            </LinearGradient>
          </TouchableOpacity>

          <Text style={styles.support}>
            UPSC · JEE · NEET · CAT · SSC CGL
          </Text>
        </Animated.View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  safe: { flex: 1, justifyContent: "center", alignItems: "center" },
  content: { alignItems: "center", paddingHorizontal: Spacing.xl },
  emoji: { fontSize: 72, marginBottom: Spacing.md },
  badge: {
    backgroundColor: "#FF6B3520",
    borderRadius: Radius.pill,
    paddingHorizontal: 16,
    paddingVertical: 5,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#FF6B3540",
  },
  badgeText: {
    ...Typography.label,
    color: Colors.spark,
    fontSize: 11,
  },
  title: {
    fontSize: 56,
    fontWeight: "800",
    color: Colors.text,
    marginBottom: 12,
    letterSpacing: -1,
  },
  subtitle: {
    ...Typography.body,
    color: Colors.textMuted,
    textAlign: "center",
    maxWidth: 300,
    marginBottom: Spacing.lg,
    lineHeight: 24,
  },
  pills: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    gap: 8,
    marginBottom: Spacing.xl,
  },
  pill: {
    backgroundColor: "#FFFFFF0A",
    borderRadius: Radius.pill,
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderWidth: 1,
    borderColor: "#FFFFFF15",
  },
  pillText: { ...Typography.small, color: "#C8C0E0", fontSize: 13 },
  ctaWrapper: { width: "100%", borderRadius: Radius.lg, overflow: "hidden", marginBottom: Spacing.md },
  cta: { paddingVertical: 18, alignItems: "center", borderRadius: Radius.lg },
  ctaText: { color: "#fff", fontWeight: "800", fontSize: 18 },
  support: { ...Typography.tiny, color: Colors.textDim, textAlign: "center", letterSpacing: 1 },
});

// mobile/App.js — Root component with navigation setup

import React, { useEffect, useRef } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { StatusBar } from "react-native";
import BackgroundFetch from "react-native-background-fetch";

import { AppProvider, useApp } from "./src/store/AppContext";
import { registerNotificationHandlers } from "./src/services/notifications";
import { headlessTask } from "./src/services/backgroundFetch";

import WelcomeScreen from "./src/screens/WelcomeScreen";
import ExamSelectScreen from "./src/screens/ExamSelectScreen";
import SubjectSelectScreen from "./src/screens/SubjectSelectScreen";
import NotificationSettingsScreen from "./src/screens/NotificationSettingsScreen";
import DashboardScreen from "./src/screens/DashboardScreen";

// Register headless background task (Android only, called when app is terminated)
BackgroundFetch.registerHeadlessTask(headlessTask);

const Stack = createStackNavigator();

function RootNavigator() {
  const { state } = useApp();
  const navigationRef = useRef(null);

  useEffect(() => {
    // Register foreground notification handlers
    const unsubscribe = registerNotificationHandlers(navigationRef);
    return () => unsubscribe?.();
  }, []);

  return (
    <NavigationContainer ref={navigationRef}>
      <StatusBar barStyle="light-content" backgroundColor="#0A0A0F" />
      <Stack.Navigator
        screenOptions={{ headerShown: false, cardStyle: { backgroundColor: "#0A0A0F" } }}
        initialRouteName={state.isSetupComplete ? "Dashboard" : "Welcome"}
      >
        <Stack.Screen name="Welcome" component={WelcomeScreen} />
        <Stack.Screen name="ExamSelect" component={ExamSelectScreen} />
        <Stack.Screen name="SubjectSelect" component={SubjectSelectScreen} />
        <Stack.Screen name="NotificationSettings" component={NotificationSettingsScreen} />
        <Stack.Screen name="Dashboard" component={DashboardScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <AppProvider>
      <RootNavigator />
    </AppProvider>
  );
}

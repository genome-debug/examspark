# ExamSpark — Full Setup Guide

## Architecture Overview

```
┌─────────────────────┐         ┌──────────────────────────────┐
│   React Native App  │ ←──── │  Node.js Backend (Express)   │
│   (iOS + Android)   │  Push  │                              │
│                     │ Notif  │  ┌─────────────────────────┐ │
│  • Welcome screen   │        │  │  Web Push (VAPID)        │ │
│  • Exam selection   │ ──────▶│  │  Subscriber Store        │ │
│  • Subject picker   │  REST  │  │  Facts Database          │ │
│  • Notif settings   │        │  │  Cron Scheduler          │ │
│  • Dashboard        │        │  └─────────────────────────┘ │
└─────────────────────┘        └──────────────────────────────┘
         │
         │ Background tasks (even when app closed)
         ▼
┌─────────────────────┐
│  Device OS          │
│  FCM (Android)      │
│  APNs (iOS)         │
└─────────────────────┘
```

---

## Step 1 — Backend Setup

```bash
cd backend
cp .env.example .env
npm install

# Generate VAPID keys (do this ONCE, save the output)
npm run generate-vapid
# → Copy VAPID_PUBLIC_KEY and VAPID_PRIVATE_KEY into .env

# Start dev server
npm run dev
# → Running on http://localhost:4000

# Test it
curl http://localhost:4000/api/health
curl http://localhost:4000/api/exams
```

### Production Deployment (Railway / Render / EC2)

```bash
# Set environment variables on your host:
PORT=4000
VAPID_PUBLIC_KEY=<from generate-vapid>
VAPID_PRIVATE_KEY=<from generate-vapid>
VAPID_EMAIL=mailto:you@yourdomain.com
FRONTEND_URL=https://yourdomain.com
NODE_ENV=production

npm start
```

> **Database**: The current store is in-memory (resets on restart).  
> For production, replace `src/store/subscribers.js` with PostgreSQL:
> ```bash
> npm install pg
> # Then implement upsert/query using `pg` pool
> ```

---

## Step 2 — Firebase Setup (Android Push)

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create project → "ExamSpark"
3. Add Android app → package: `com.examspark`
4. Download `google-services.json` → place in `mobile/android/app/`
5. Copy **Server Key** from Firebase → Project Settings → Cloud Messaging

> Note: Since we're using Raw Web Push (VAPID) on the backend,  
> FCM is only used to **deliver** the push to Android devices.  
> The backend calls the FCM endpoint with VAPID auth — no Firebase SDK needed on the backend.

---

## Step 3 — iOS APNs Setup

1. In Apple Developer Console → Certificates → Create APNs Auth Key (.p8)
2. Note your: Team ID, Key ID, Bundle ID (`com.examspark`)
3. Add to backend `.env`:
   ```
   APNS_KEY_PATH=./certs/AuthKey_XXXXXXXX.p8
   APNS_KEY_ID=XXXXXXXX
   APNS_TEAM_ID=XXXXXXXXXX
   APNS_BUNDLE_ID=com.examspark
   ```

---

## Step 4 — React Native App Setup

```bash
cd mobile
npm install

# Android
npx react-native run-android

# iOS
cd ios && pod install && cd ..
npx react-native run-ios
```

### Required Native Config

**Android** — `android/app/src/main/AndroidManifest.xml`:
```xml
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
<uses-permission android:name="android.permission.VIBRATE"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>

<!-- Background Fetch -->
<service android:name="com.transistorsoft.tsbackgroundfetch.BackgroundFetchHeadlessTask"
  android:exported="false"/>
```

**iOS** — `ios/ExamSpark/Info.plist`:
```xml
<key>UIBackgroundModes</key>
<array>
  <string>fetch</string>
  <string>remote-notification</string>
</array>
```

---

## Step 5 — Connect App to Backend

Update `mobile/src/services/api.js`:
```js
const BASE_URL = __DEV__
  ? "http://10.0.2.2:4000/api"         // Android emulator
  : "https://YOUR_BACKEND_URL/api";    // ← Replace with your deployed URL
```

Update `mobile/src/services/notifications.js`:
```js
senderID: "YOUR_FIREBASE_SENDER_ID",  // ← From Firebase Console
```

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Server health + subscriber count |
| GET | `/api/exams` | All exams & subjects |
| GET | `/api/vapid-public-key` | VAPID public key for client |
| POST | `/api/subscribe` | Register device for notifications |
| PATCH | `/api/subscribe` | Update preferences |
| DELETE | `/api/subscribe` | Unsubscribe |
| POST | `/api/spark` | Trigger immediate notification |

### POST /api/subscribe — Request Body
```json
{
  "subscription": {
    "endpoint": "<FCM/APNs device token>",
    "keys": { "platform": "android" }
  },
  "exam": "UPSC",
  "subjects": ["Indian History", "Geography", "Polity"],
  "intervalMinutes": 30,
  "distractMode": false
}
```

---

## How Push Notifications Work

```
1. App starts → requests notification permission
2. OS issues FCM/APNs device token
3. App sends token + prefs to backend POST /api/subscribe
4. Backend stores subscription, sends welcome spark
5. Cron runs every minute → checks who is "due"
6. Backend calls web-push → FCM/APNs delivers to device
7. Device shows notification even if app is closed
8. User taps → app opens to Dashboard/TopicDetail

Distract Mode:
  Cron runs every 30 seconds → sends burst to all distractMode=true subscribers
  Background Fetch on device also fires local notifications when app is backgrounded
```

---

## Folder Structure

```
examsparkapp/
├── backend/
│   ├── src/
│   │   ├── index.js              # Express server
│   │   ├── routes/index.js       # All REST endpoints
│   │   ├── services/
│   │   │   ├── pushService.js    # web-push wrapper
│   │   │   └── scheduler.js      # cron jobs
│   │   ├── store/
│   │   │   └── subscribers.js    # in-memory store (→ replace with DB)
│   │   ├── data/
│   │   │   └── facts.js          # all exam facts & syllabus
│   │   └── utils/
│   │       └── generateVapid.js  # one-time VAPID key generator
│   ├── .env.example
│   └── package.json
│
└── mobile/
    ├── App.js                    # Root + navigation
    ├── src/
    │   ├── screens/
    │   │   ├── WelcomeScreen.js
    │   │   ├── ExamSelectScreen.js
    │   │   ├── SubjectSelectScreen.js
    │   │   ├── NotificationSettingsScreen.js
    │   │   └── DashboardScreen.js
    │   ├── services/
    │   │   ├── api.js            # Backend REST calls
    │   │   ├── notifications.js  # notifee + permission + channels
    │   │   └── backgroundFetch.js# Background task for distract mode
    │   ├── store/
    │   │   └── AppContext.js     # Global state + AsyncStorage persist
    │   └── utils/
    │       └── theme.js          # Colors, typography, spacing
    └── package.json
```

---

## Next Steps to Complete the App

1. **Add a database** — Replace `subscribers.js` with PostgreSQL using `pg`
2. **Add more facts** — Expand `backend/src/data/facts.js` (aim for 50+ per subject)
3. **Topic detail screen** — When user taps notification, show full syllabus breakdown
4. **Streak tracking** — Track daily notification interactions on backend
5. **App Store submission** — Follow React Native release guide for signed APKs/IPAs

---

*Built with ❤️ for India's competitive exam aspirants*
